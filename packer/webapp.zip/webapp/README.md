# webapp

# build and Deploy instructions for the web application.

# install all the dependencies below
# npm i express
# npm i sequelize
# npm i mysql2
# npm install dotenv
# npm install bcrypt

# Add .env file

# execute node app.js
#test comment

